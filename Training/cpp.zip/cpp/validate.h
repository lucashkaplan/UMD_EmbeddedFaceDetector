#ifndef validate_h
#define validate_h

#include <stdio.h>
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <algorithm>
#include <iomanip>
#include <cmath>
#include <chrono>

using namespace std;

void write_config(feature**, vector<opt_feat>&, string); 

#endif
