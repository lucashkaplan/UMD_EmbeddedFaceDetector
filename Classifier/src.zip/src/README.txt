Actors and Graph

