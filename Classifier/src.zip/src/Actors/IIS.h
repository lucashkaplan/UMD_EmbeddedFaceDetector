#ifndef IIS_h
#define IIS_h

/*******************************************************************************
DESCRIPTION:
This header tile holds the definition for an indexed image subwindow variable
*******************************************************************************/

typedef struct IIS{
	int img[24][24];
	int k;
} IIS;

#endif
